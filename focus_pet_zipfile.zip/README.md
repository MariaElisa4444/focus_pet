# Projekti kirjeldus

FocusPet on rakendus, mis aitab keskenduda õppimisele ja tööle. Kasutaja alustab ajamõõtmist ning samal ajal hakkab kasvama virtuaalne lemmikloom. Loom kasvab ja areneb vastavalt sellele, kui järjekindlalt ja kaua kasutaja fookusseansse teeb.
Tahame aidata inimesi, kellel on raske keskenduda või kellel kipub õppimine venima. Rakendus loob mõnusa ja motiveeriva keskkonna, mis teeb keskendumise lihtsamaks ja aitab kujundada paremaid õppimisharjumusi.

Autorid: Maria Elisa Vassiljeva, Viktorija Korjagina
